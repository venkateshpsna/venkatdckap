<!DOCTYPE html>
<html>
<head>
<title>Online Store</title>
<meta charset="utf-8" />
<meta name="viewpoint" content="width=device-width,initial-scal=1.0">
<meta http-equip="X-UA-compatible" content="ie=edge">

<link rel="stylesheet" type="text/css" href="<?php echo e(url('resources/style.css')); ?>">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>

<body>

<section id="nav-bar">
		<nav class="navbar navbar-expand-lg navbar-light">
  		
  		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    			<span class="navbar-toggler-icon"></span>
  		</button>
  		<div class="topnav">
  		<a style="color:black;" class="active" >DCKAP</a>
		</div> 
  		<div class="collapse navbar-collapse" id="navbarNav">
			
    		<ul class="navbar-nav ml-auto">
    	
      		<li class="nav-item">
        		<a style="color:black;" class="nav-link" href="<?php echo e(route('checkout.page')); ?>">Checkout</a>
      		</li>
      		
      		
    		</ul>
  		</div>
		</nav>

		
	
	
<section class="new-arrivals">
<div id="site">
	<div class="container">
		<div class="title-box">
		<h2><a href="<?php echo e(route('addproduct.page')); ?>">Add Product</a></h2>
		</div>
		<div class="row">
			
			<?php $__currentLoopData = $myproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myproducts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
		  <div class="col-md-3">
			<div class="product-top" > 
				<img style="height:150px;" src="<?php echo e(url('public/productimg/'.$myproducts->image)); ?>"> 
			</div>
			<div class=" text-center">
			<h3><?php echo e($myproducts->name); ?></h3>
				<div class="product-description" data-name="Mirror" data-price="10">
				
				<p class="product-prices" style="margin-top: -1px;margin-bottom: 0rem;">Price:<?php echo e($myproducts->price); ?></p>
				
					<?php echo csrf_field(); ?>
					
						<label for="qty-2">Quantity</label>
						<input type="text" name="qty" style="width:60px;" id="qty<?php echo $myproducts->id;?>" class="qty" value="1" />
						<input type="hidden" name="productid" id="productid<?php echo $myproducts->id;?>" value="<?php echo e($myproducts->id); ?>" />
						<input type="hidden" name="image" id="image<?php echo $myproducts->id;?>"  value="<?php echo e($myproducts->image); ?>" />
						<input type="hidden" name="shortdes" id="shortdes<?php echo $myproducts->id;?>" value="<?php echo e($myproducts->shortdescription); ?>" />
						<input type="hidden" name="price" id="price<?php echo $myproducts->id;?>" value="<?php echo e($myproducts->price); ?>" />
						<input type="hidden" name="name" id="name<?php echo $myproducts->id;?>" value="<?php echo e($myproducts->name); ?>" />
				
				</br>
					<p><input type="button" value="Add to cart" class="addproduct" attr="<?php echo $myproducts->id;?>" /></p>
			
				</div>
			</div>
		  </div>			
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<!------COntact------------>	
<section id="contact" style="padding-bottom: 11px;">	
	
</section>
</body>
</html>	

<script>
	$(document).ready(function(){

		//alert('hi');
		$(".addproduct").on('click', function(e){
		//$(".addproduct").onclick(function(event){
			event.preventDefault();
			$.ajaxSetup({
				headers: {
					'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
				}
				});

			var id = $(this).attr('attr');
			var qty = $("#qty"+id).val();
			var image = $("#image"+id).val();
			var shortdes = $("#shortdes"+id).val();
			var name = $("#name"+id).val();
			var price = $("#price"+id).val();
			if(!/^[0-9]+$/.test(qty)){
				alert("Please enter Quantity in numbers only");
				return false;
			}
			$.ajax({
				url:"<?php echo e(url('/sessionproductadd')); ?>",
				type:"POST",
				data:{'id':id,'qty':qty,'image':image,'shortdes':shortdes,'name':name,'price':price},
				success: function(data)
				{
					$("#qty"+id).val('1');
					console.log(data);
					alert('Product Added Successfully');
					//location.reload();
				}
			})

		});
	})
	</script>
<?php /**PATH C:\xampp\htdocs\dckapvenkat\resources\views/index.blade.php ENDPATH**/ ?>