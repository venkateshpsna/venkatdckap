<!DOCTYPE html>
<html>
<head>
<title>Online Store</title>
<meta charset="utf-8" />
<meta name="viewpoint" content="width=device-width,initial-scal=1.0">
<meta http-equip="X-UA-compatible" content="ie=edge">

<link rel="stylesheet" type="text/css" href="<?php echo e(url('resources/style.css')); ?>">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>

<body>

<section id="nav-bar">
		<nav class="navbar navbar-expand-lg navbar-light">
  		
  		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    			<span class="navbar-toggler-icon"></span>
  		</button>
  		<div class="topnav">
  		<a style="color:black;" class="active" href="#home">DCKAP</a>
		</div> 
  		<div class="collapse navbar-collapse" id="navbarNav">
  		
    		<ul class="navbar-nav ml-auto">
      		<li class="nav-item">
        		<a style="color:black;" class="nav-link" href="<?php echo e(route('checkout.page')); ?>">Checkout</a>
      		</li>
      		
      		
    		</ul>
  		</div>
		</nav>

<!------COntact------------>	
<section id="contact">
	<div class="col-md-6">	
	<a href="<?php echo e(route('productlist')); ?>">Back To List</a>
	</div>
	<div class="container">
		<h1>Add Product</h1>
		<div class="row">
			<div class="col-md-3">
			</div>
			<div class="col-md-6">
				<form class="contact-form" id="addproduct" name="addproduct" type="post">
					<?php echo csrf_field(); ?>
				<div class="form-group">
				<input type="text" class="form-control" name="name" id="name" required placeholder="Product Name..">
				</div>
				<div class="form-group">
					<textarea class="form-control" name="shortdesc" id="shortdesc" required rows="4" placeholder="Short Description.."></textarea>
					</div>
					<div class="form-group">
						<textarea class="form-control" name="desc" id="desc" required rows="4" placeholder="Description.."></textarea>
						</div>
				<div class="form-group">
				<input type="file" required class="form-control" name="image" id="image">
				</div>
				<div class="form-group">
					<input type="text" class="form-control" name="price" id="price" required placeholder="Product Price..">
					</div>
					<div class="form-group">
						<select class="form-control" name="status" id="status" required>
							<option value="1">Active
							</option>
							<option value="2">InActive
							</option>
						</select>
						</div>
				<center><button type="submit" class="btn btn-primary">Submit</button></center>
				
				</form>
			</div>

			
		</div>

	</div>

</section>

</body>
</html>	
<script>
	$(document).ready(function(){

		//alert('hi');

		$("#addproduct").submit(function(event){
			event.preventDefault();
			var price = $("#price").val();
			if(!/^[0-9]+$/.test(price)){
				alert("Please only Price in number only");
				return false;
			}
			$.ajax({
				url:"<?php echo e(url('/addproductpost')); ?>",
				type:"POST",
				data:new FormData (this),
				dataType:'JSON',
				cache:false,
				contentType: false,
				processData: false,
				success: function(data)
				{
					alert('Product Added Successfully');
					location.reload();
				}
			})

		});
	})
	</script>
<?php /**PATH C:\xampp\htdocs\dckapvenkat\resources\views/addproduct.blade.php ENDPATH**/ ?>