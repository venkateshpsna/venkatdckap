<?php
namespace App;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $guarded = array('id');
    protected $table = 'product';
    public $timestamps = true;
}
