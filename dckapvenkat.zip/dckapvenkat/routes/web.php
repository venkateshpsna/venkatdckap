<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/* Route::get('/', function () {
    return view('welcome');
}); */  
Route::get('/','ProductController@index')->name('productlist');
Route::get('/addproduct','ProductController@appProduct')->name('addproduct.page');
Route::post('/addproductpost','ProductController@postProduct')->name('postaddproduct');
Route::post('/sessionproductadd','ProductController@postsessionProduct')->name('sessionproductadd');
Route::get('/checkoutpage','ProductController@checkoutPage')->name('checkout.page');
Route::post('/sessionproductdelete','ProductController@productDelete')->name('sessionproductdelete.page');
Route::post('/checkoutorder','ProductController@checkoutProduct')->name('checkoutorder.page');



