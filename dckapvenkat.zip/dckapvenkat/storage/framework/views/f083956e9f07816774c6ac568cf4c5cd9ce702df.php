<!DOCTYPE html>
<html>
<head>
<title>Your Shopping Cart</title>
<meta charset="utf-8" />

<link rel="stylesheet" type="text/css" href="<?php echo e(url('resources/style.css')); ?>">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>

<body>

<div id="site">

	<div class="col-md-6">	
		<a href="<?php echo e(route('productlist')); ?>">Back To List</a>
		</div>
	<div id="content">
		<h1>Checkout</h1>
		<form class="contact-form" id="addproduct" name="addproduct" type="post">
			<table class="table table-hover" id="cart-table">
				
				<thead>
					<tr>
					<th scope="col-4">Product</th>
					<th scope="col-2">Product Name</th>
					<th scope="col-2">Quantity</th>
					<th scope="col-2">Price</th>
					<th scope="col-2">Short Description</th>
					<th scope="col-1">Total</th>
					<th scope="col-1"></th>
					</tr>
				</thead>
				<tbody>
				<?php 
				//print_r($cartItems);
				//exit;
				$finaltotal = 0;
				$total = 0;
				
				if(isset($cartItems))
				{
				?>
				<?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
				<?php
				$total = $cartItems['qty'] * $cartItems['price'];
				$finaltotal += $total;
				?>
				<tr > 
					<td scope="row"><img src="<?php echo e(url('public/productimg/'.$cartItems['image'])); ?>" style="width: 72px; height: 72px; border: 1px solid #d0d0d0; padding: 5px;"></td>
					<td><?php echo e($cartItems['name']); ?></td>
					<td>
						<span>
						
						<input type="text" readonly class="form-control" style="width:50px;" value="<?php echo e($cartItems['qty']); ?>"  id="num_qty<?php echo $cartItems['id']?>" name="num_qty" />
						
						</span>
					</td>
					<td><strong><input type="text" readonly class="form-control" style="width:130px;" value="&#8377;<?php echo e($cartItems['price']); ?>" /></strong> </td>
					<td><textarea disabled><?php echo e($cartItems['shortdes']); ?></textarea></td>
					<td><strong><input type="text" readonly class="form-control" style="width:130px;" value="&#8377;<?php echo number_format($total,2,'.','');?>" /></strong> </td>
				
				
					<td> <a href="javascript:void(0)" class='delete-cart' product_id="<?php echo e($cartItems['id']); ?>" attr1="<?php echo e($cartItems['id']); ?>" data-attr="<?php echo e($cartItems['id']); ?>" style="color: #da3340;"><i class="fa fa-trash-o" aria-hidden="true"></i></a> </td>

 
				</tr>
			
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php 
				}
				?>
				</tbody>
			</table>
			<p id="sub-total">
				<strong style="margin-right: 100px;">Sub Total: &#8377;<?php echo number_format($finaltotal,2,'.','');?></strong>
				<input type="hidden" name="total" id="total" value="<?php echo $finaltotal?>"/>
			</p>
			<div class="row">
				<div class="col-md-3">
				</div>
				<div class="col-md-6">
					
						<?php echo csrf_field(); ?>
					<div class="form-group">
					<input type="text" class="form-control" name="name" id="name" required placeholder="Your Name..">
					</div>
					<div class="form-group">
						<input type="text" class="form-control" name="email" id="email" required placeholder="Your Email..">
						</div>
						<div class="form-group">
							<input type="text" class="form-control" name="number" id="number" required placeholder="Your Number..">
							</div>
					<div class="form-group">
						<textarea class="form-control" name="address" id="address" required rows="4" placeholder="Your Address.."></textarea>
						</div>
						
					<center><button type="submit" class="btn btn-primary">Place Order</button></center>
					
					</form>
				</div>
	
				
			</div>
		</form>
	</div>
	
	

</div>

</body>
</html>	
<script>
    $('.delete-cart').on('click', function(){
        //const tablecount = $('#cart-table >tbody >tr').length;
        //alert(tablecount);
        /* if(tablecount > 1)
        { */
			
            var id = $(this).attr('attr1');
			event.preventDefault();
			$.ajaxSetup({
				headers: {
					'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
				}
				});
			//var myqty = $("#qty"+myattr).val();
				/* alert(myattr);
				alert(myqty); */
			$.ajax({
				url:"<?php echo e(url('/sessionproductdelete')); ?>",
				type:"POST",
				data:{'id':id},
				success: function(data)
				{
					//console.log(data);
					alert('Product Deleted Successfully');
					location.reload();
				}
			});
            
       });
	   $("#addproduct").submit(function(event){
		   var total = $("#total").val();
		   var number = $("#number").val();
		   if(total == 0)
		   {
				alert("Please Purchase Any Product To process");
				return false;
		   }
		   if(!/^[0-9]+$/.test(number)){
				alert("Please only enter your mobilenumber");
				return false;
			}
			event.preventDefault();
			$.ajax({
				url:"<?php echo e(url('/checkoutorder')); ?>",
				type:"POST",
				data:new FormData (this),
				dataType:'JSON',
				cache:false,
				contentType: false,
				processData: false,
				success: function(data)
				{
					alert('Order Placed Successfully');
					window.location.replace("<?php echo e(url('/')); ?>");
				}
			})

		});
</script>
<?php /**PATH C:\xampp\htdocs\dckapvenkat\resources\views/cart.blade.php ENDPATH**/ ?>