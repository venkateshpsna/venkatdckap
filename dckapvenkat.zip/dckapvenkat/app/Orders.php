<?php
namespace App;
use Illuminate\Database\Eloquent\Model;

class Orders extends Model
{
    protected $guarded = array('id');
    protected $table = 'orders';
    public $timestamps = true;
}
