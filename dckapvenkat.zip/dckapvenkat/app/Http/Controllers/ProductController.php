<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\Customer;
use App\Orders;
use DB;
use Session;

class ProductController extends Controller
{
    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
       
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $myproducts = DB::table('product')->where('status',1)->get();
        return view('index')->with('myproducts', $myproducts);
    }
    public function appProduct()
    {
        return view('addproduct');
    }
    public function postProduct(Request $request)
    {
            $product = new Product;
            $product->name = $request->name;
            $product->shortdescription = $request->shortdesc;
            $product->description = $request->desc;
            $product->price = $request->price;
           
                $file = $request->file('image') ; 
                $fileName =  time().'_'.$file->getClientOriginalName() ;
                $destinationPath = public_path().'/productimg' ;
                $file->move($destinationPath,$fileName);
                $product->image = $fileName ;
            $product->status = $request->status;
            $product->save();
            $last_insert_id = $product->id;
            $outputdata =array('status'=>'success','last_insert_id' => $last_insert_id);
            return response()->json($outputdata);
    }
    public function postsessionProduct(Request $request)
    {  
        //data:{'id':id,'qty':qty,'image':image,'shortdes':shortdes,'name':name},
        $product = $request->all();
        $cart = Session::get('cart');
        if(isset($cart[$product['id']])):
            $cart[$product['id']]['qty'] += $request->qty; // Dynamically update qty
            
        else:
            $cart[$product['id']] = $product;
            $cart[$product['id']]['qty'] = $request->qty;  // Dynamically add qty
            $cart[$product['id']]['image'] = $request->image;
            $cart[$product['id']]['shortdes'] = $request->shortdes;
            $cart[$product['id']]['name'] = $request->name;
            $cart[$product['id']]['price'] = $request->price;
        endif;
        Session::put('cart', $cart);
        $outputdata =array('status'=>'success','last_insert_id' => count(Session::get('cart')));
                return response()->json($outputdata);
    }
    public function checkoutPage()
    {
        $cartItems = Session::get('cart');
        return view('cart')->with('cartItems', $cartItems);
    }
    public function productDelete(Request $request)
    {
        $product = $request->all();
        $cart = Session::get('cart');
       // $cart[$product['id']]['qty'] = 0;
       unset($cart[$product['id']]); 
        Session::put('cart', $cart);
        $outputdata =array('status'=>'success','last_insert_id' => count(Session::get('cart')));
                return response()->json($outputdata);
    }
    
    public function checkoutProduct(Request $request)
    {
        $customer = new Customer;
        $customer->name = $request->name;
        $customer->email = $request->email;
        $customer->number = $request->number;
        $customer->address = $request->address;
        $customer->totalprice = $request->total;
        $customer->save();
        $customerid = $customer->id;

        $cartItems = Session::get('cart');
        foreach ($cartItems as $cartItems)
        {
            $total = $cartItems['qty'] * $cartItems['price'];
            $cartItems['image'];
            $orders = new Orders;
            $orders->customerid = $customerid;
            $orders->productid = $cartItems['id'];
            $orders->qty = $cartItems['qty'];
            $orders->price = $total;
            $orders->save();
        }
        $request->session()->flush();
        $outputdata =array('status'=>'success','last_insert_id' => $customerid);
        return response()->json($outputdata);
    }
}
